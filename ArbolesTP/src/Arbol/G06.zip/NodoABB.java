package Arbol;

public class NodoABB {
	int dato;
	TDAABB hijoIzq;
	TDAABB hijoDer;

}
